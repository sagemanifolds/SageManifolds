from manifold import Manifold, RealLine
from functions import xder
from utilities import set_axes_labels
# from sage.symbolic.pynac import textbook_style_deriv, omit_function_args





