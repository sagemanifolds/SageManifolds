Tensors
=======

.. toctree::
   :maxdepth: 2

   sage/tensor/modules/tensor_free_module

   sage/tensor/modules/free_module_tensor

   sage/tensor/modules/tensor_with_indices
