from manifold import Manifold, RealLine
from functions import xder
from utilities import set_axes_labels, nice_derivatives, omit_function_args 
